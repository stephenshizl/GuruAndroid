# AIDLService-sample
This is the source code related to this blog: 

1. http://www.race604.com/communicate-with-remote-service-1
2. http://www.race604.com/communicate-with-remote-service-2
3. http://www.race604.com/communicate-with-remote-service-3
